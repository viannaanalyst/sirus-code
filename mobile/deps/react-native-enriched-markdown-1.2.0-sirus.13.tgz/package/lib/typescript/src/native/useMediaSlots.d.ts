import type { LayoutChangeEvent, NativeSyntheticEvent } from 'react-native';
import type { DocumentAssetsEventInternal, MediaLayoutEventInternal } from '../EnrichedMarkdownNativeComponent';
import type { EnrichedMarkdownTextProps } from '../types/MarkdownTextProps';
export declare function useMediaSlots(markdown: string, parserKey: string, renderMedia: EnrichedMarkdownTextProps['renderMedia'], onDocumentAssets: EnrichedMarkdownTextProps['onDocumentAssets'], resolveImageSource: EnrichedMarkdownTextProps['resolveImageSource']): {
    slots: (import("react/jsx-runtime").JSX.Element | null)[];
    onNativeLayout: ({ nativeEvent }: LayoutChangeEvent) => void;
    nativeProps: {
        documentRevision: number;
        enableDocumentAssets: boolean;
        enableMediaSlots: boolean;
        mediaOverridesRevision: number;
        mediaOverrides: {
            id: string;
            height: number;
            width: number;
            url: string;
            kind: "video" | "image";
            anchor: string;
        }[];
        onDocumentAssets: (event: NativeSyntheticEvent<DocumentAssetsEventInternal>) => void;
        onMediaLayout: (event: NativeSyntheticEvent<MediaLayoutEventInternal>) => void;
        enableImageSourceResolution: boolean;
        imageSourcesContinuityStart: number;
        imageSourcesRevision: number;
        imageSources: import("../EnrichedMarkdownNativeComponent").ImageSourceInternal[];
    };
};
//# sourceMappingURL=useMediaSlots.d.ts.map