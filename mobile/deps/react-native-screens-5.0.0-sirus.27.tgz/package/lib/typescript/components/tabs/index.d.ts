import { TabsHost } from './host';
import { TabsScreen } from './screen';
export type { TabsHostNavStateRequest, TabSelectedEvent, TabSelectionRejectedEvent, TabSelectionRejectionReason, TabSelectionPreventedEvent, TabsHostColorScheme, TabsHostDirection, TabsHostNativeContainerStyleProps, TabsHostPropsBase, TabsHostProps, TabsHostPropsAndroid, MoreTabSelectedEvent, TabsBottomAccessoryComponentFactory, TabBarMinimizeBehavior, TabBarControllerMode, TabBarSidebarPreferredPlacement, TabsHostPropsIOS, } from './host';
export type { TabsScreenEventHandler, TabsScreenOrientation, TabsScreenPropsBase, TabsScreenProps, TabsScreenIconAndroid, TabsScreenIconTintingAndroid, TabBarItemLabelVisibilityMode, TabsScreenItemStateAppearanceAndroid, TabsScreenAppearanceAndroid, TabsScreenPropsAndroid, TabsScreenIconIOS, TabsScreenIconImageRenderingModeIOS, TabsScreenIconSymbolRenderingModeIOS, TabsScreenIconTemplateIOS, TabsScreenIconXcassetIOS, TabsScreenBlurEffect, TabsScreenRole, TabsScreenSystemItem, TabsScreenAppearanceIOS, TabsScreenItemAppearanceIOS, TabsScreenItemStateAppearanceIOS, TabsScreenPropsIOS, } from './screen';
export type { TabsBottomAccessoryEnvironment } from './bottom-accessory';
export declare const Tabs: {
    Host: typeof TabsHost;
    Screen: typeof TabsScreen;
};
//# sourceMappingURL=index.d.ts.map