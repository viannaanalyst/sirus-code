import React from 'react';
import type { StackHostProps } from './StackHost.types';
/**
 * EXPERIMENTAL API, MIGHT CHANGE W/O ANY NOTICE
 */
declare function StackHost(props: StackHostProps): React.JSX.Element;
export default StackHost;
//# sourceMappingURL=StackHost.d.ts.map