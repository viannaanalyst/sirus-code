import type { ReactElement } from 'react';
import type { ColorValue, TextStyle } from 'react-native';
import type { SearchBarProps } from '../../../legacy/types';
import type { PlatformIconIOS } from '../../shared/types';
import type { StackHeaderMenuIOS } from './ios/StackHeaderMenu.ios.types';

/**
 * @summary Options for updating a menu action (leaf item) at runtime.
 *
 * @description
 * Omitted keys preserve current values. Explicit `undefined` resets to default.
 *
 * @platform ios
 */
export interface StackHeaderMenuItemOptionsIOS {
  /**
   * @summary Sets the application-controlled state displayed next to an action.
   *
   * @description
   * Applies only when `itemType` resolves to `action`. Ignored for native toggles.
   * Omission preserves the current state; explicit `undefined` resets it to `off`.
   * Does not emit press or selection callbacks.
   *
   * @platform ios
   */
  state?: 'off' | 'on' | 'mixed' | undefined;
  /**
   * @summary New title for the menu action.
   *
   * @platform ios
   */
  title?: string | undefined;
  /**
   * @summary New icon for the menu action.
   *
   * @platform ios
   */
  icon?: PlatformIconIOS | undefined;
  /**
   * @summary Sets the toggle state of the menu item.
   *
   * @description
   * When inside a single selection hierarchy, setting `true` deselects the
   * previously selected item and selects this one. Setting `false` is a noop
   * in this case - only has effect for regular toggles.
   *
   * @platform ios
   */
  toggleState?: boolean | undefined;
}

/**
 * @summary Options for updating a submenu at runtime.
 *
 * @description
 * Omitted keys preserve current values. Explicit `undefined` resets to default.
 *
 * @platform ios
 */
export interface StackHeaderMenuOptionsIOS {
  /**
   * @summary New title for the submenu.
   *
   * @platform ios
   */
  title?: string | undefined;
  /**
   * @summary New icon for the submenu.
   *
   * @platform ios
   */
  icon?: PlatformIconIOS | undefined;
}

export interface StackHeaderBaseItemIOS {
  /**
   * @summary A unique identifier within the screen header.
   *
   * @platform iOS
   */
  id: string;
  /**
   * @summary A title for the item that is displayed in the header.
   *
   * @platform iOS
   */
  title?: string | undefined;
  /**
   * @summary Icon displayed for the header item.
   *
   * @description
   * Supports SF Symbols, xcassets, and image sources. For async image sources,
   * the item renders without an icon first and updates when loaded.
   * Ignored when custom view ({@link StackHeaderInlineCustomItemIOS.render | render}) is set.
   *
   * @platform iOS
   */
  icon?: PlatformIconIOS | undefined;
}

export interface SupportsMenuIOS {
  /**
   * @summary Menu definition for the context menu that appears when item is tapped.
   *
   * @platform iOS
   */
  menu?: StackHeaderMenuIOS | undefined;
  /**
   * @summary Menu definition substituting the item when it is displayed in a menu.
   *
   * @description
   * When the system moves the item into a menu (e.g. the navigation bar
   * overflow menu), this menu is displayed in its place. Useful for custom items
   * ({@link StackHeaderInlineCustomItemIOS.render | render}), which iOS doesn't display in the overflow menu otherwise.
   * The `id`s used in the menu are expected to be unique across every `menu` and `menuRepresentation`.
   *
   * @platform iOS
   *
   * @supported iOS 16 and higher
   */
  menuRepresentation?: StackHeaderMenuIOS | undefined;
}

export interface SupportsSharedBackgroundIOS {
  /**
   * @summary Whether the liquid glass background for this item should be hidden.
   *
   * @description
   * On iOS 26, adjacent bar button items are grouped inside a shared liquid
   * glass background. Setting this to `true` removes the shared background
   * from this item.
   *
   * @default false
   *
   * @platform iOS
   *
   * @supported iOS 26 and higher
   */
  hidesSharedBackground?: boolean | undefined;
}

export type StackHeaderItemAxisBehaviorIOS =
  | 'automatic'
  | 'horizontalOnly'
  | 'verticalPreferred';

export interface SupportsAxisBehaviorIOS {
  /**
   * @summary Supported bar axes and preferred placement for this item.
   *
   * @description
   * Matches UIKit's `UIBarButtonItem.axisBehavior`.
   * - `automatic`: UIKit infers supported axes from the item's contents.
   * - `horizontalOnly`: only supports horizontal bars. The item is hidden
   *   when no horizontal bar is present.
   * - `verticalPreferred`: supports both axes and prefers vertical placement
   *   when both horizontal and vertical bars are present.
   *
   * Removing this option restores `automatic`. Ignored on older iOS versions
   * and on other platforms.
   *
   * @default automatic
   * @platform iOS
   * @supported iOS 27.1 and higher, when built with the iOS 27.1 SDK or newer
   */
  axisBehavior?: StackHeaderItemAxisBehaviorIOS | undefined;
}

/**
 * @summary Priority used when the header has to decide which items to keep.
 *
 * @description
 * Each value maps to the matching `UIBarButtonItemVisibilityPriority` constant.
 *
 * @platform iOS
 *
 * @supported iOS 27 and higher
 */
export type StackHeaderItemVisibilityPriorityIOS = 'low' | 'standard' | 'high';

export interface SupportsVisibilityPriorityIOS {
  /**
   * @summary Decides which items give way first when the header runs out of room.
   *
   * @description
   * When the items do not fit, the header moves the ones with the lowest
   * priority into the overflow ("...") menu, and keeps the higher ones.
   *
   * Accepts `'low'`, `'standard'` (the default) and `'high'`, which map to the
   * `UIBarButtonItemVisibilityPriority` constants. Only the relative order of
   * the items matters.
   *
   * When the item is placed in an implicit group of items, the group
   * inherits this priority.
   *
   * A custom item ({@link StackHeaderInlineCustomItemIOS.render | render})
   * moved into the overflow menu has no content to show there.
   *
   * @default 'standard'
   *
   * @platform iOS
   *
   * @supported iOS 27 and higher
   */
  visibilityPriority?: StackHeaderItemVisibilityPriorityIOS | undefined;
}

export interface SupportsIdentifierIOS {
  /**
   * @summary Stable identifier used to match the item across different screens
   * for more intelligent animation on transition.
   *
   * @description
   * When navigating between screens, iOS tries to match similarly looking items (i.e. same sfSymbol)
   * and animate between them. If the heuristic fails, a simpler crossfade is applied.
   * In a situation where visually different items should be logically considered the same across screens,
   * you may use this prop to tell this fact to the system. The identifier shouldn't be updated at runtime;
   * doing so will result in item rebuild and visual flash.
   *
   * @platform iOS
   *
   * @supported iOS 26 and higher
   */
  identifier?: string | undefined;
}

/**
 * @summary Visual variant (style) of a header item.
 *
 * @description
 * - `plain`: the default look of a bar button item.
 * - `prominent`: the item is emphasized with a tinted background.
 *   On iOS below 26 it falls back to bold text (the `done` style).
 *
 * @platform iOS
 */
export type StackHeaderItemVariantIOS = 'plain' | 'done' | 'prominent';

/**
 * @summary Native header item with text label.
 *
 * @platform iOS
 */
export interface StackHeaderInlineItemIOS
  extends StackHeaderBaseItemIOS,
    SupportsMenuIOS,
    SupportsIdentifierIOS,
    SupportsAxisBehaviorIOS,
    SupportsSharedBackgroundIOS,
    SupportsVisibilityPriorityIOS {
  /** Button tint, including the background of a prominent button. */
  tintColor?: ColorValue | undefined;
  /** Uses UIKit's search placement item on iOS 26 and later. */
  searchBarPlacement?: boolean | undefined;
  /**
   * @summary Marks this object as a header item definition.
   *
   * @platform iOS
   */
  type: 'item';
  /**
   * @summary Visual variant (style) of the item.
   *
   * @default 'plain'
   *
   * @platform iOS
   */
  variant?: StackHeaderItemVariantIOS | undefined;
  /**
   * @summary Whether the item is disabled.
   *
   * @description
   * A disabled item is grayed out and does not respond to user interaction:
   * neither {@link StackHeaderInlineItemIOS.onPress | onPress} nor
   * {@link SupportsMenuIOS.menu | menu} is triggered.
   *
   * @default false
   *
   * @platform iOS
   */
  disabled?: boolean | undefined;
  /**
   * @summary Callback invoked when the header item is pressed.
   *
   * @description
   * Fires when the user taps the header item. When combined with
   * {@link SupportsMenuIOS.menu | menu}, tapping fires `onPress` and
   * long-pressing shows the menu.
   *
   * @platform iOS
   */
  onPress?: (() => void) | undefined;
}

/**
 * @summary Header item with custom view.
 *
 * @platform iOS
 */
export interface StackHeaderInlineCustomItemIOS
  extends SupportsMenuIOS,
    SupportsIdentifierIOS,
    SupportsAxisBehaviorIOS,
    SupportsSharedBackgroundIOS,
    SupportsVisibilityPriorityIOS {
  /**
   * @summary A unique identifier within the screen header.
   *
   * @platform iOS
   */
  id: string;
  /**
   * @summary Marks this object as a header item definition.
   *
   * @platform iOS
   */
  type: 'item';
  /**
   * @summary A function that renders the custom view.
   *
   * @description
   * The subview is sized by React Native's layout engine but positioned by the
   * platform native layout. Each item's size is calculated independently and will
   * not respect flex layout. Use static width and height for best results.
   *
   * @platform iOS
   */
  render: () => ReactElement;
}

/**
 * @summary A spacer item for visual separation of items.
 *
 * @description Separates items defined in {@link StackHeaderConfigPropsIOS.leadingItems | leadingItems}
 * and {@link StackHeaderConfigPropsIOS.trailingItems | trailingItems}. The fixed size spacing works
 * for iOS 18 and below, for iOS 26 it only splits liquid glass bubble for two adjacent items.
 *
 * @platform iOS
 */
interface StackHeaderFixedSpacerItemIOS {
  /**
   * @summary A unique identifier within the screen header.
   *
   * @platform iOS
   */
  id: string;
  /**
   * @summary Marks this object as a spacer definition.
   *
   * @platform iOS
   */
  type: 'spacer';
  /**
   * @summary Marks this object as a fixed-size spacer definition.
   *
   * @platform iOS
   */
  sizing: 'fixed';
  /**
   * @summary Specifies space width between adjacent header items.
   *
   * @platform iOS
   */
  width: number;
}

/**
 * @summary A spacer item for visual separation of items.
 *
 * @description Separates items defined in {@link StackHeaderConfigPropsIOS.leadingItems | leadingItems}
 * and {@link StackHeaderConfigPropsIOS.trailingItems | trailingItems}.
 * For iOS 26 it splits liquid glass bubble for two adjacent items.
 *
 * @platform iOS
 */
interface StackHeaderFlexibleSpacerItemIOS {
  /**
   * @summary A unique identifier within the screen header.
   *
   * @platform iOS
   */
  id: string;
  /**
   * @summary Marks this object as a spacer definition.
   *
   * @platform iOS
   */
  type: 'spacer';
  /**
   * @summary Marks this object as a flexible-size spacer definition.
   *
   * @platform iOS
   */
  sizing: 'flexible';
}

/**
 * @summary A header spacer item type
 */
export type StackHeaderSpacerItemIOS =
  | StackHeaderFixedSpacerItemIOS
  | StackHeaderFlexibleSpacerItemIOS;

export interface StackHeaderTitleCustomItemIOS {
  /**
   * @summary A unique identifier within the screen header.
   *
   * @platform iOS
   */
  id: string;
  /**
   * @summary A function that renders the custom view.
   *
   * @description
   * The subview is sized by React Native's layout engine but positioned by the
   * platform native layout. Each item's size is calculated independently and will
   * not respect flex layout. Use static width and height for best results.
   *
   * Note: Due to layout process limitations, text view will not resize and
   * ellipsize to fit available space without manually setting desired view
   * width. For text-only elements that should ellipsize it is recommended to
   * use regular `title` instead.
   *
   * @platform iOS
   */
  render: () => ReactElement;
}

/**
 * @summary Controls how the back button title is displayed.
 *
 * @description
 * - `default`: the system chooses the title depending on available space.
 *   On iOS < 26 options include: custom title (defaults to previous screen title),
 *   generic "Back", no title; on iOS >= 26 it's either custom title (if set) or no title.
 * - `generic`: on iOS < 26, the system uses a generic "Back" title or no title;
 *   on iOS >= 26 it's the same as `minimal`.
 * - `minimal`: no title is displayed next to the back button chevron.
 *
 * @platform iOS
 */
export type StackHeaderBackButtonDisplayModeIOS =
  | 'default'
  | 'generic'
  | 'minimal';

/**
 * @summary UIKit navigation item layout style.
 *
 * @description
 * - `navigator`: traditional navigation, with a centered title.
 * - `browser`: a leading-aligned title in supported layouts.
 * - `editor`: a leading-aligned title in supported layouts and a chevron-only
 *   back button.
 *
 * UIKit adapts title placement to the device and available space.
 *
 * @platform iOS
 *
 * @supported iOS 16 and higher
 */
export type StackHeaderNavigationItemStyleIOS =
  | 'navigator'
  | 'browser'
  | 'editor';

/**
 * @summary Controls when the navigation bar minimizes in response to scrolling.
 *
 * @description
 * - `automatic`: the system determines the minimization behavior.
 * - `never`: the navigation bar does not minimize.
 * - `onScrollDown`: the navigation bar minimizes when the user scrolls down.
 * - `onScrollUp`: the navigation bar minimizes when the user scrolls up.
 *
 * @platform iOS
 */
export type StackHeaderMinimizationBehaviorIOS =
  | 'automatic'
  | 'never'
  | 'onScrollDown'
  | 'onScrollUp';

/**
 * @summary Controls when a minimized navigation bar restores.
 *
 * @description
 * - `automatic`: the system determines the restoration behavior. By default
 *   the navigation bar restores when the user reverses scroll direction.
 * - `atScrollEdge`: the navigation bar restores only when the scroll view's
 *   content reaches the scroll edge. Honored only together with
 *   `minimizationBehavior: 'onScrollDown'`.
 *
 * @platform iOS
 */
export type StackHeaderRestorationBehaviorIOS = 'automatic' | 'atScrollEdge';

export interface StackHeaderAppearanceIOS {
  /**
   * @summary Specifies the background color of the navigation bar.
   *
   * @description Replaces the default background material. Alpha is preserved,
   * so `transparent` removes this appearance's background. Omit to use UIKit's
   * default for this appearance. Automatic scroll-edge effects are unaffected.
   *
   * @platform ios
   */
  backgroundColor?: ColorValue | undefined;
  /**
   * @summary Specifies the color of the shadow below the navigation bar.
   *
   * @description Use `transparent` to hide the shadow. Omit to use UIKit's
   * default for this appearance.
   *
   * @platform ios
   */
  shadowColor?: ColorValue | undefined;
  /**
   * @summary Specifies the font family used for the title of the header.
   *
   * @platform ios
   */
  titleFontFamily?: TextStyle['fontFamily'] | undefined;
  /**
   * @summary Specifies the font size used for the title of the header.
   *
   * @platform ios
   */
  titleFontSize?: TextStyle['fontSize'] | undefined;
  /**
   * @summary Specifies the font weight used for the title of the header.
   *
   * @platform ios
   */
  titleFontWeight?: TextStyle['fontWeight'] | undefined;
  /**
   * @summary Specifies the font style used for the title of the header.
   *
   * @platform ios
   */
  titleFontStyle?: TextStyle['fontStyle'] | undefined;
  /**
   * @summary Specifies the font color used for the title of the header.
   *
   * @platform ios
   */
  titleFontColor?: TextStyle['color'] | undefined;
  /**
   * @summary Specifies the font family used for the large title of the header.
   *
   * @platform ios
   */
  largeTitleFontFamily?: TextStyle['fontFamily'] | undefined;
  /**
   * @summary Specifies the font size used for the large title of the header.
   *
   * @platform ios
   */
  largeTitleFontSize?: TextStyle['fontSize'] | undefined;
  /**
   * @summary Specifies the font weight used for the large title of the header.
   *
   * @platform ios
   */
  largeTitleFontWeight?: TextStyle['fontWeight'] | undefined;
  /**
   * @summary Specifies the font style used for the large title of the header.
   *
   * @platform ios
   */
  largeTitleFontStyle?: TextStyle['fontStyle'] | undefined;
  /**
   * @summary Specifies the font color used for the large title of the header.
   *
   * @platform ios
   */
  largeTitleFontColor?: TextStyle['color'] | undefined;
  /**
   * @summary Specifies the font family used for the subtitle of the header.
   *
   * @description Applies to both the regular and the large subtitle.
   *
   * @platform ios
   *
   * @supported iOS 26 and higher
   */
  subtitleFontFamily?: TextStyle['fontFamily'] | undefined;
  /**
   * @summary Specifies the font size used for the subtitle of the header.
   *
   * @description Applies to both the regular and the large subtitle.
   *
   * @platform ios
   *
   * @supported iOS 26 and higher
   */
  subtitleFontSize?: TextStyle['fontSize'] | undefined;
  /**
   * @summary Specifies the font weight used for the subtitle of the header.
   *
   * @description Applies to both the regular and the large subtitle.
   *
   * @platform ios
   *
   * @supported iOS 26 and higher
   */
  subtitleFontWeight?: TextStyle['fontWeight'] | undefined;
  /**
   * @summary Specifies the font style used for the subtitle of the header.
   *
   * @description Applies to both the regular and the large subtitle.
   *
   * @platform ios
   *
   * @supported iOS 26 and higher
   */
  subtitleFontStyle?: TextStyle['fontStyle'] | undefined;
  /**
   * @summary Specifies the font color used for the subtitle of the header.
   *
   * @description Applies to both the regular and the large subtitle.
   *
   * @platform ios
   *
   * @supported iOS 26 and higher
   */
  subtitleFontColor?: TextStyle['color'] | undefined;
}

export interface StackHeaderConfigPropsIOS {
  /** Tint for native back buttons, header items and toolbar items. */
  tintColor?: ColorValue | undefined;
  /**
   * @summary Search bar displayed in the native navigation header.
   *
   * @description
   * Pass a single `<SearchBar />` element. Its existing props, events and ref
   * commands configure the native search controller. Removing or replacing
   * the element dismisses the previous search controller. Search is dismissed
   * when the screen loses focus; returning does not automatically focus it.
   *
   * Ignored on tvOS, Android and web.
   *
   * @platform iOS
   */
  searchBar?: ReactElement<SearchBarProps> | undefined;
  /**
   * @summary Controls the current screen's UIKit navigation item layout style.
   *
   * @description
   * Maps to `UINavigationItem.style`. Removing the option restores `navigator`.
   * Ignored before iOS 16 and on tvOS.
   *
   * @default 'navigator'
   *
   * @platform iOS
   *
   * @supported iOS 16 and higher
   */
  navigationItemStyle?: StackHeaderNavigationItemStyleIOS | undefined;
  /**
   * @summary Title displayed next to the back button on this screen.
   *
   * @description
   * Configured on the screen whose back button it applies to (the screen that
   * is pushed on top). When unset, the system derives the back title from the
   * previous screen's `title`.
   *
   * @platform iOS
   */
  backButtonTitle?: string | undefined;
  /**
   * @summary Controls how the back button title is displayed.
   *
   * @default 'default'
   *
   * @platform iOS
   */
  backButtonDisplayMode?: StackHeaderBackButtonDisplayModeIOS | undefined;
  /**
   * @summary Whether the back button shows the navigation history menu.
   *
   * @description
   * Configured on the screen whose back button it applies to (the screen that
   * is pushed on top). When `false`, the navigation history menu is not shown
   * on either of the gestures that normally open it: long-pressing the back
   * button and secondary-clicking it (trackpad / mouse right click); tapping
   * it still pops the screen.
   *
   * @default true
   *
   * @platform iOS
   */
  backButtonMenuEnabled?: boolean | undefined;
  /**
   * @summary Custom item to display as a subtitle.
   *
   * @description Takes precedence over subtitle text.
   *
   * @platform iOS
   *
   * @supported iOS 26 and higher
   */
  subtitleItem?: StackHeaderTitleCustomItemIOS | undefined;
  /**
   * @summary A list of items placed starting from the leading edge.
   *
   * @description Items are placed next to the back button, if present. If there
   * is not enough space to fit all leading items at once, they are all moved to
   * overflow menu. This differs from trailing items, which are moved one by one.
   *
   * Note: Custom items are not put into the overflow menu, but are removed entirely.
   *
   * @platform iOS
   */
  leadingItems?:
    | (
        | StackHeaderInlineItemIOS
        | StackHeaderInlineCustomItemIOS
        | StackHeaderSpacerItemIOS
      )[]
    | undefined;
  /**
   * @summary Custom item to display as a title.
   *
   * @description Takes precedence over title text.
   *
   * @platform iOS
   */
  titleItem?: StackHeaderTitleCustomItemIOS | undefined;
  /**
   * @summary Menu definition for the title context menu.
   *
   * @description
   * Configures a dropdown menu attached to the navigation bar title area.
   * Works independently of {@link titleItem}; the menu appears for both
   * plain text and custom view title.
   *
   * @platform iOS
   *
   * @supported iOS 16 and higher
   */
  titleMenu?: StackHeaderMenuIOS | undefined;
  /**
   * @summary A list of items placed starting from the trailing edge.
   * If there is not enough space to fit some items, they are moved to the overflow menu, one by one.
   *
   * Note: Custom items are not put into the overflow menu, but are removed entirely.
   *
   * @platform iOS
   */
  trailingItems?:
    | (
        | StackHeaderInlineItemIOS
        | StackHeaderInlineCustomItemIOS
        | StackHeaderSpacerItemIOS
      )[]
    | undefined;
  /**
   * @summary Items displayed in the native bottom toolbar for this screen.
   *
   * @description Items are ordered from the leading edge. Use fixed or flexible
   * spacers to position them. Omitting this prop or passing an empty array hides
   * the toolbar. Navigating to another screen displays that screen's toolbar
   * items. The toolbar is independent of the header's `hidden` prop.
   *
   * Ignored on Android and tvOS.
   *
   * @platform iOS
   */
  toolbarItems?:
    | (
        | StackHeaderInlineItemIOS
        | StackHeaderInlineCustomItemIOS
        | StackHeaderSpacerItemIOS
      )[]
    | undefined;
  /**
   * @summary Large title text, displayed when `largeTitleEnabled = true`.
   *
   * @description When ScrollView is present on the screen, large header is displayed only when
   * fully scrolled to top, otherwise it collapses to regular header. If `largeTitle` is not defined,
   * it falls back to regular title.
   *
   * @platform iOS
   */
  largeTitle?: string | undefined;
  /**
   * @summary Specifies if the header should display the large title. It collapses to a regular header when scrolling.
   *
   * @platform iOS
   */
  largeTitleEnabled?: boolean | undefined;
  /**
   * @summary Large subtitle text, displayed when `largeTitleEnabled = true`.
   *
   * @description When ScrollView is present on the screen, large header is displayed only when
   * fully scrolled to top, otherwise it collapses to regular header. If `largeSubititle` is not defined,
   * it falls back to regular subtitle.
   *
   * @platform iOS
   *
   * @supported iOS 26 and higher
   */
  largeSubtitle?: string | undefined;
  /**
   * @summary Custom item to display as a subtitle for large header. Takes precedence over largeSubtitle text.
   *
   * @platform iOS
   *
   * @supported iOS 26 and higher
   */
  largeSubtitleItem?: StackHeaderTitleCustomItemIOS | undefined;
  /**
   * @summary A single line of text displayed at the top of the navigation bar,
   * above the title.
   *
   * @description
   * Setting this prop increases the height of the navigation bar.
   *
   * @platform iOS
   */
  prompt?: string | undefined;
  /**
   * @summary Controls when the navigation bar minimizes in response to scrolling.
   *
   * @description
   * When the navigation bar minimizes, an integrated top tab bar minimizes as well.
   *
   * @default 'automatic'
   *
   * @platform iOS
   *
   * @supported iOS 27 and higher
   */
  minimizationBehavior?: StackHeaderMinimizationBehaviorIOS | undefined;
  /**
   * @summary Controls when a minimized navigation bar restores.
   *
   * @description
   * Currently honored only together with `minimizationBehavior: 'onScrollDown'`.
   * With other minimization behaviors, the system falls back to `automatic`.
   *
   * @default 'automatic'
   *
   * @platform iOS
   *
   * @supported iOS 27 and higher
   */
  restorationBehavior?: StackHeaderRestorationBehaviorIOS | undefined;
  /**
   * @summary Appearance of the header when the edge of scrollable content
   * is not aligned with the edge of the header.
   *
   * @platform ios
   */
  standardAppearance?: StackHeaderAppearanceIOS | undefined;
  /**
   * @summary Appearance of the header when the edge of scrollable content
   * is aligned with the edge of the header.
   *
   * @description If unset, UIKit derives the configuration from `standardAppearance`.
   * An explicit appearance is independent of `standardAppearance` and starts with
   * a transparent background unless `backgroundColor` is set.
   *
   * @platform ios
   */
  scrollEdgeAppearance?: StackHeaderAppearanceIOS | undefined;
}

export interface StackHeaderConfigCommandsIOS {
  /**
   * @summary Updates properties of a menu action (leaf item) at runtime.
   *
   * @param menuElementId The ID of the menu action to update.
   * @param options Object with properties to change. Omitted keys preserve current
   *        values. Explicit `undefined` resets to default.
   *
   * @platform ios
   */
  setMenuItemOptions: (
    menuElementId: string,
    options: StackHeaderMenuItemOptionsIOS,
  ) => void;
  /**
   * @summary Updates properties of a submenu at runtime.
   *
   * @param menuElementId The ID of the submenu to update.
   * @param options Object with properties to change. Omitted keys preserve current
   *        values. Explicit `undefined` resets to default.
   *
   * @platform ios
   */
  setMenuOptions: (
    menuElementId: string,
    options: StackHeaderMenuOptionsIOS,
  ) => void;
}
